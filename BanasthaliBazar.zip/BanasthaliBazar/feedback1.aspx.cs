﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Xml.Linq;
using System.Net.Mail;
using System.IO;
using System.Data;


namespace BanasthaliBazar
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\feedback.mdf;Integrated Security=True;User Instance=True");

        protected void Page_Load(object sender, EventArgs e)
        {

         if(!IsPostBack)
         {
             bindrepeaterdata();
         }

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into feedback (uname,fb,pdt) values (@uname,@fb,@pdt)",con);
            cmd.Parameters.AddWithValue("@uname",txtuname.Text);
            cmd.Parameters.AddWithValue("@fb",txtfb.Text);
              cmd.Parameters.AddWithValue("@pdt",DateTime.Now);
            cmd.ExecuteNonQuery();
            con.Close();
            txtuname.Text = string.Empty;
            txtfb.Text = string.Empty;
            bindrepeaterdata();

            }

        protected void bindrepeaterdata()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from feedback order by pdt desc", con);
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            Repeater1.DataSource = ds;
            Repeater1.DataBind();
            con.Close();

        }

    }
}