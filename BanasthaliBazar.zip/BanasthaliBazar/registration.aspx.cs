﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using AjaxControlToolkit;


namespace BanasthaliBazar
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\userinfo.mdf;Integrated Security=True;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnreg_Click(object sender, EventArgs e)
        {
            if (CheckBox1.Checked == true)
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("insert into userinfo values('" + txtname.Text + "','" + txtphno.Text + "','" + txteid.Text + "','" + txtuname.Text + "','" + txtpwd.Text + "')", con);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Redirect("login.aspx");


            }
        }
    }
}