﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;

namespace BanasthaliBazar
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\pdt.mdf;Integrated Security=True;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        
      

        protected void btn1_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                if (FileUpload1.PostedFile.ContentType == "image/jpeg" || FileUpload1.PostedFile.ContentType == "image/png")
                {
                    //if (FileUpload1.PostedFile.ContentLength <= 102400)
                    //{
                        string fname = Path.GetFileName(FileUpload1.PostedFile.FileName);
                        FileUpload1.SaveAs(Server.MapPath("~/upload/") + fname);
                        Image1.ImageUrl = "~/upload/" + fname;

                    //}
                    //else
                      //  Label1.Text = "File size should be <= 1MB";

                }
                else
                    Label1.Text = "Only jpeg/jpg and png is allowed";
            }
            else
                Label1.Text = "File does not exist";

           
        
        }

        protected void btn2_Click(object sender, EventArgs e)
        {
            if (FileUpload2.HasFile)
            {
                if (FileUpload2.PostedFile.ContentType == "image/jpeg")
                {
                   // if (FileUpload1.PostedFile.ContentLength <= 1024000)
                    //{
                        string fname1 = Path.GetFileName(FileUpload2.PostedFile.FileName);
                        FileUpload2.SaveAs(Server.MapPath("~/upload/") + fname1);
                        Image2.ImageUrl = "~/upload/" + fname1;
                    //}
                    //else
                      //  Label2.Text = "File size should be <= 1MB";

                }
                else
                    Label2.Text = "Only jpeg/jpg and png is allowed";
            }
            else
                Label1.Text = "File does not exist";

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            con.Open();
             string fname = FileUpload1.PostedFile.FileName;
             string imgname =Image1.ImageUrl;
             string fname1 = FileUpload2.PostedFile.FileName;
             string imgname1 =Image2.ImageUrl;
             SqlCommand cmd = new SqlCommand("insert into pdt values('" + addes.Text + "','" + dd1.SelectedItem + "','" + adtitle.Text + "','" + imgname + "','" + imgname1 + "','" + price.Text + "','" + phno.Text + "','" + hostel.Text + "','" + sid.Text + "')", con);
             cmd.ExecuteNonQuery();
             con.Close();
             Response.Redirect("profile.aspx");

        }
    }
}