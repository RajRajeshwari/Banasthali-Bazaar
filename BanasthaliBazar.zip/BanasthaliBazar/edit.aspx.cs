﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace BanasthaliBazar
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\userinfo.mdf;Integrated Security=True;User Instance=True");
        string str;
        protected void Page_Load(object sender, EventArgs e)
        {

            con.Open();
            string s = Session["a"].ToString();
            Response.Write(s);

            Label1.Text = s;
            SqlCommand cmd1 = new SqlCommand("select name from userinfo where uname='" + s + "'", con);
            SqlDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                Label2.Text = dr1[0].ToString();
            }
            con.Close();
            con.Open();
            SqlCommand cmd2 = new SqlCommand("select pwd from userinfo where uname='" + s + "'", con);
            SqlDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                Label3.Text = dr2[0].ToString();
            }
            con.Close();
            con.Open();
            SqlCommand cmd3 = new SqlCommand("select eid from userinfo where uname='" + s + "'", con);
            SqlDataReader dr3 = cmd3.ExecuteReader();
            while (dr3.Read())
            {
                Label4.Text = dr3[0].ToString();
            }
            con.Close();
            con.Open();
            SqlCommand cmd4 = new SqlCommand("select phno from userinfo where uname='" + s + "'", con);
            SqlDataReader dr4 = cmd4.ExecuteReader();

            while (dr4.Read())
            {
                Label5.Text = dr4[0].ToString();
            }
            con.Close();
        }
        static int a = 0, b = 0, c = 0, d = 0;

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (a == 0)
            {
                Panel1.Visible = true;
                a = 1;
            }
            else
            {
                a = 0;
                Panel1.Visible = false;
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (b == 0)
            {
                Panel2.Visible = true;
                b = 1;
            }
            else
            {
                b = 0;
                Panel2.Visible = false;
            }

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            if (c == 0)
            {
                Panel3.Visible = true;
                c = 1;
            }
            else
            {
                c = 0;
                Panel3.Visible = false;
            }

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            if (d == 0)
            {
                Panel4.Visible = true;
                d = 1;
            }
            else
            {
                d = 0;
                Panel4.Visible = false;
            }

        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Panel1.Visible = false;
            Panel2.Visible = false;
            Panel3.Visible = false;
            Panel4.Visible = false;
         
            string s = Session["a"].ToString();
            con.Open();
            if (TextBox1.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update userinfo set name ='" + TextBox1.Text + "' where uname ='" + s + "'", con);
                cmd.ExecuteNonQuery();
            }
            con.Close();
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select pwd from userinfo where uname ='" + s + "'", con);
            SqlDataReader dr = cmd1.ExecuteReader();
            while (dr.Read())
            {
                str = dr[0].ToString();
            }
            con.Close();
            con.Open();
            if ((str == TextBox2.Text) && (TextBox3.Text != ""))
            {
                SqlCommand cmd2 = new SqlCommand("update userinfo set pwd ='" + TextBox3.Text + "' where uname ='" + s + "'", con);
                cmd2.ExecuteNonQuery();

            }
            con.Close();
            con.Open();
            if (TextBox5.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update userinfo set eid ='" + TextBox5.Text + "' where uname ='" + s + "'", con);
                cmd.ExecuteNonQuery();
            }
            con.Close();
            con.Open();
            if (TextBox6.Text != "")
            {
                SqlCommand cmd = new SqlCommand("update userinfo set phno ='" + TextBox6.Text + "' where uname ='" + s + "'", con);
                cmd.ExecuteNonQuery();
            }
            Response.Redirect("edit.aspx");

        }

        
    }
}