﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Xml.Linq;
using System.Net.Mail;
using System.IO;

namespace BanasthaliBazar
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\userinfo.mdf;Integrated Security=True;User Instance=True");
       
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
              con.Open();
            SqlCommand cmd = new SqlCommand("select pwd from userinfo where uname='" + TextBox1.Text + "'", con);
            
            SqlDataReader dr = cmd.ExecuteReader();
            

            con.Close();
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select eid from userinfo where uname='" + TextBox1.Text + "'", con);
            SqlDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                MailMessage msg = new MailMessage(new MailAddress("banasthalibazaar@gmail.com"),new MailAddress( dr1[0].ToString()));
                msg.Subject = "Retrieved Password";
                msg.IsBodyHtml = true;
                msg.Body = "Your password is " + dr1[0].ToString() + ".";
                System.Net.NetworkCredential networkcredential = new System.Net.NetworkCredential("banasthalibazaar@gmail.com", "shreshuhimraj1234");
                SmtpClient smptclient = new SmtpClient();
                smptclient.EnableSsl = true;
                smptclient.UseDefaultCredentials = false;
                smptclient.Credentials = networkcredential;
                smptclient.Host = "smpt.gmail.com";
                smptclient.Port = 587;
                // smptclient.Send(msg);
                Label1.Text = "E-mail Sent Successfully to " + dr1[0].ToString() + ".";

            }
        }
    }
}