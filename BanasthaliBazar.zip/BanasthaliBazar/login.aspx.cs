﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Security;

namespace BanasthaliBazar
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\userinfo.mdf;Integrated Security=True;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
             if (CheckBox1.Checked)
            {

                Response.Cookies["username"].Expires = DateTime.Now.AddDays(30);
                Response.Cookies["password"].Expires = DateTime.Now.AddDays(30);

            }
            else
            {
                Response.Cookies["username"].Expires = DateTime.Now.AddDays(-1);
                Response.Cookies["password"].Expires = DateTime.Now.AddDays(-1);
                

            }
            
            Response.Cookies["username"].Value = txtuname.Text.Trim();
            Response.Cookies["password"].Value = txtpwd.Text.Trim();
        
            con.Open();
            //string uname = txtuname.Text;
            //string pwd = txtpwd.Text;
            SqlCommand cmd = new SqlCommand("select uname,pwd from userinfo where uname='"+txtuname.Text+"' and pwd='"+txtpwd.Text+"'", con);
           // cmd.Parameters.Add(new SqlParameter("@uname", "uname here"));
           // cmd.Parameters.Add(new SqlParameter("@pwd", "pwd here"));
             
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                
                Session["a"]= txtuname.Text ;
                con.Close();
                
                Response.Redirect("profile.aspx");
             
            }
            else
            {
                Label1.Text = "Incorrect Username or Password!";
            }
                      

        }

        protected void txtuname_TextChanged(object sender, EventArgs e)
        {
            if (Request.Cookies["username"] != null)
            {
                txtpwd.Attributes["value"] = Request.Cookies["password"].Value;

            }

        }
        
    }
}