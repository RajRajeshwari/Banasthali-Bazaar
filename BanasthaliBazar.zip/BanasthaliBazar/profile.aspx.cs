﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;

namespace BanasthaliBazar
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\pdt.mdf;Integrated Security=True;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = Session["a"].ToString();
            con.Open();
            SqlCommand cmd =new SqlCommand("select* from pdt where sid='"+Label1.Text+"'",con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
                Button1.Visible = true;
            else
                Button1.Visible = false;
            con.Close();


          
        }

     
        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Response.Redirect("main.aspx");
        }

        protected void btnpost_Click(object sender, EventArgs e)
        {
            Response.Redirect("product.aspx");
        }
        static int d = 1;
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (d == 1)
            {
                Panel3.Visible = true;
                d = 0;
            }
            else
            {
                Panel3.Visible = false;
                d = 1;
            }

        }

        protected void btndel_Click(object sender, EventArgs e)
        {   
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from pdt where title ='" + txtdel.Text + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            Panel3.Visible = false;
            GridView2.DataBind();
            Response.Redirect("profile.aspx");
        }

        protected void btnep_Click(object sender, EventArgs e)
        {
            Response.Redirect("edit.aspx");
        }

   

       
    }
}